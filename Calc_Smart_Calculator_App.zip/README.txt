CALC — SMART CALCULATOR

Files:
- index.html: calculator app
- manifest.json and sw.js: install/offline support when hosted on HTTPS or localhost

Quick use on Android:
1. Open index.html in a browser or HTML viewer to test the calculator.
2. To install it as a proper app icon and enable offline support, host the folder on an HTTPS static host (for example GitHub Pages or Netlify).
3. Open the HTTPS URL in Chrome on Android.
4. Use Chrome menu (⋮) > Install app or Add to Home screen.

Important:
- This is a Progressive Web App (PWA), not a signed Android APK.
- Service worker installation requires HTTPS or localhost. Opening the file directly still allows the calculator to work, but PWA install/offline caching may not work.
- No calculator inputs are uploaded or stored by this app.
